package springjdbc.hr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JobsDAO {
	
	@Autowired
	JdbcTemplate templ;
	
	void getCount() {
	System.out.println(templ.queryForObject("SELECT COUNT(*) FROM JOBS", Integer.class));	
	}
}
