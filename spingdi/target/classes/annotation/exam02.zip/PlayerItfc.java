package annotation.exam02;

public interface PlayerItfc {
	public void play();
	public int getTotalValue();
}
