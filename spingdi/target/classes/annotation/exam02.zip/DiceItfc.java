package annotation.exam02;

public interface DiceItfc {
	public int getDiceValue();
}
