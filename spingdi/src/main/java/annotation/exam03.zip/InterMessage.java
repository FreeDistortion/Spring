package annotation.exam03;

public interface InterMessage {
	void sayHello();
}
