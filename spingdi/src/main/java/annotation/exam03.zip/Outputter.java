package annotation.exam03;

public interface Outputter {
	void output(String message);
}
