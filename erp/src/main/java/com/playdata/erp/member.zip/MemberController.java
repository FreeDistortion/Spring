package com.playdata.erp.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MemberController {
	
	private static final String String = null;
	MemberService serv;

	public MemberController() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	public MemberController(MemberService serv) {
		super();
		this.serv = serv;
	}
	
	@GetMapping("/emp/login")
	public String showLoginPage() {
		
		return "emp/login";
	}
	
	@PostMapping("/emp/login")
	public String login(MemberDTO member) {
		String path;
		MemberDTO dto=serv.login(member);
		System.out.println(dto);
		if(dto!=null) {
			path = "redirect:/board/list?category=all";
		}else {
			path = "emp/login"; 
		}
		return path;
	}
	
}
